package com.app;

import com.app.exception.CustomFileNotFoundException;
import com.app.services.InputProcessor;
import com.app.services.OutputProcessor;

public class App {

	/**
	 * If no argument is provided then the input file present inside
	 * main.com.app.logic package is picked up as input file by default.
	 * 
	 * @param args
	 * @throws CustomFileNotFoundException
	 */
	public static void main(String[] args) throws CustomFileNotFoundException {
		String filePath = null;
		if (args.length != 0)
			filePath = args[0];
		try {
			InputProcessor.ProcessFile(filePath);
			InputProcessor.MapTokentoIntegerValue();
			OutputProcessor.processReplyForQuestion();
		} catch (Exception e) {
			throw new CustomFileNotFoundException(e.getMessage());
		}
	}

}
