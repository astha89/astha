package com.app.exception;
import com.app.enums.ExceptionType;
/*
 * This class is responsible to show valid & meaningful exception 
 */

public class CustomFileNotFoundException extends Exception{
	
	private static final long serialVersionUID = 1L;

	public CustomFileNotFoundException(String message){
		super(message);
		System.out.println("\n" + ExceptionType.ERROR + ": Input file is not present or corrupt.Please check file and act accordingly.");
	}	
	
	public CustomFileNotFoundException(String customizedMsg, String message){
		super(message);
		System.out.println("\n" + ExceptionType.WARN + " : "+customizedMsg);
		System.out.println("\n" + ExceptionType.ERROR + ": Input file is not present or corrupt.Please check file and act accordingly.");
	}
}
