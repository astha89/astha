/**
 * 
 */
package com.app.exception;

/**
 * @author Astha
 *
 */
public class UnknownSymbolException extends Exception {

	public UnknownSymbolException(String message) {
		super(message);
	
	}
}
