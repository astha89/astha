package com.app.exception;

import com.app.enums.ExceptionType;

public class CustomRomanToDecimalException extends Exception{
	
	private static final long serialVersionUID = 1L;

	public CustomRomanToDecimalException(String message){
		super(message);
		System.out.println("\n" + ExceptionType.ERROR + ": Roman number is not valid. Please check and provide valid roman number for conversion.");
	}	
	
	public CustomRomanToDecimalException(String customMsg, String message){
		super(message);
		System.out.println("\n" + ExceptionType.WARN + " : "+ customMsg);
		System.out.println("\n" + ExceptionType.ERROR + ": Roman number is not valid. Please check and provide valid roman number for conversion.");
	}	

}
