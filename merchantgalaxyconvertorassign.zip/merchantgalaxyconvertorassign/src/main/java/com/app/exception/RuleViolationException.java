/**
 * 
 */
package com.app.exception;

/**
 * @author Astha
 *
 */
public class RuleViolationException extends Exception {

	
	
	public RuleViolationException(String message) {
		super(message);
	}

	
	
	
	
	
	
	
	
	
	
	
	
	
}
